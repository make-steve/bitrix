<?
$PERM["confirm"]["2"]="R";
?>