<?
$sSectionName = "Company";
$arDirProperties = Array(

);
?>