<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("Contact Information");
?>
<p><b>E-mail Addresses:</b></p>
 
<table border="0" width="100%"> 	
  <tbody>
    <tr> 		<td width="20%">General information:</td> 		<td>info@company.com</td> 	</tr>
   	
    <tr> 		<td>Sales:</td> 		<td>sales@company.com</td> 	</tr>
   	
    <tr> 		<td>Technical support:</td> 		<td>support@company.com</td> 	</tr>
   </tbody>
</table>
 
<p><b>Phone Numbers:</b></p>
 
<table border="0" width="100%"> 	
  <tbody>
    <tr> 		<td width="20%">Main:</td> 		<td>+1 (555) 432-2920</td> 	</tr>
   	
    <tr> 		<td>Toll-free sales line (US only):</td> 		<td>800-827-0685 (no technical support calls at this number)</td> 	</tr>
   	
    <tr> 		<td>International sales:</td> 		<td>+1 (555) 432-2920</td> 	</tr>
   	
    <tr> 		<td>Technical support:</td> 		<td>+1 (555) 432-2920</td> 	</tr>
   	
    <tr> 		<td>Fax:</td> 		<td>+1 (555) 432-2857</td> 	</tr>
   </tbody>
</table>
 
<p><b>Company</b> is a California Corporation.</p>
 
<p><b>Corporate Headquarters:</b></p>
 <dl> <dd><b>Company</b>, Inc.</dd><dt>
    <br />
  </dt> <dd>*** Pine Avenue, 4th Floor</dd><dt>
    <br />
  </dt> <dd>Long Beach, CA 90802</dd><dt>
    <br />
  </dt> <dd>USA</dd><dt>
    <br />
  </dt> </dl> 
<p><b>Office Hours:</b></p>
 
<p>Monday - Friday (closed during most major holidays), 8 AM - 5 PM GMT - 8:00.</p>
 
<p><b>See the scheme how to reach the office:</b></p>
 
<p><img height="449" width="500" src="/images/company/about/address_1.png" /></p>
 
<p><b>Minnesota Office:</b></p>
 <dl> <dd>*** Gilbert Building</dd><dt>
    <br />
  </dt> <dd>*** Wacouta Street</dd><dt>
    <br />
  </dt> <dd>St. Paul, MN 55101</dd><dt>
    <br />
  </dt> <dd>USA</dd><dt>
    <br />
  </dt> </dl> 
<p><b>See the scheme how to reach the office:</b></p>
 
<p><img height="418" width="490" src="/images/company/about/address_2.png" /></p>
<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>