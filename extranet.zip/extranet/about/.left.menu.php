<?
$aMenuLinks = Array(
	Array(
		"Company", 
		"/extranet/about/index.php", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Contact Information", 
		"/extranet/about/contacts.php", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Banking Details", 
		"/extranet/about/bank_info.php", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Subscription", 
		"/extranet/about/subscribe.php", 
		Array(), 
		Array(), 
		"" 
	)
);
?>