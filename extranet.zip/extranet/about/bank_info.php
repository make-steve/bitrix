<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("Banking Details");
?>
<p>Please use the following official banking details:</p>
 
<p><b>Bank address</b>:</p>
 <dl> <dd>Citibank N.A.</dd><dt> 
    <br />
   </dt> <dd>111 Wall Street</dd><dt> 
    <br />
   </dt> <dd>New York, New York 10043</dd><dt> 
    <br />
   </dt> <dd>U.S.A.</dd><dt> 
    <br />
   </dt> </dl> 
<p>Account Name: <b>Company</b> Account Name</p>
 
<p>Account Number: 36658729</p>
 
<p>Swift Code: COTUS033</p>
 
<p>ABA Routing Code: 022386589</p>
 
<p>Clearinghouse CHIPS ID: 0008</p>
<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>