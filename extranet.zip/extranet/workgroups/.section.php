<?
$sSectionName="My Groups";
?>