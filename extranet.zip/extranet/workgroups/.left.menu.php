<?
$aMenuLinks = Array(
	Array(
		"My Groups", 
		"/extranet/workgroups/index.php", 
		Array(), 
		Array(), 
		"" 
	)
);
?>