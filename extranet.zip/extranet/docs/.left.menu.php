<?
$aMenuLinks = Array(
	Array(
		"Common Documents", 
		"/extranet/docs/shared/", 
		Array("/extranet/docs/index.php"), 
		Array(), 
		"" 
	)
);
?>