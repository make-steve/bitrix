<?
$sSectionName = "Home";
$arDirProperties = array(

);
?>