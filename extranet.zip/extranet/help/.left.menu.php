<?
$aMenuLinks = Array(
	Array(
		"Help", 
		"/extranet/help/index.php", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"MS Outlook Integration", 
		"/extranet/help/outlook.php", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Technical Support", 
		"/extranet/help/support.php?show_wizard=Y", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Extranet", 
		"/extranet/help/extranet.php", 
		Array(), 
		Array(), 
		"" 
	)
);
?>