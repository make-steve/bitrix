<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("Extranet");
?>
<b>Extranet</b> is a private area for secure cooperation with partners, customers, clients, contractors, distributors and other external users that can be granted access to communication with the company's personnel.
<br />
 
<br />
Extranet's most notable advantages:
<br />
 
<ul> 
  <li>a single information access point for employees, clients and partners;</li>
 
  <li>provision for confidential communications;</li>
 
  <li>extensive teamwork functions (support for remote employees);</li>
 
  <li>secure external access to workgroup information;</li>
 
  <li>transparent and easily formalized communications.</li>
 </ul>
Authorized employees can invite external users to join Extranet and discuss essential questions in the forums or blogs; edit documents in teamwork mode; plan events in calendars; perform tasks and watch their progress; and more.
<br />
 
<br />
Extranet is a place to meet, a desk to work, and a board to plan. Enjoy!
<br />
 
<br />
<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>