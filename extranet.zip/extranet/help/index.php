<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("Help");
?>
<p>We are recommending to view the following pages:</p>
 
<p><a href="/extranet/about/">About company</a> - official and unofficial information you should know about our company. There you will read about the making of the company and the main lines of activity. This chapter also contains useful information: company baking details, addresses and phones.</p>

<p><a href="/extranet/contacts/index.php">Search Contacts</a> to quickly find an external site user or an employee with respect to your access permission; define the person's current availability status; obtain their contact information. You can find a person by the department or company and/or the name, or you can take advantage of the extended search functions which will search, in addition, by the e-mail address and keywords. Each person  (or user in terms of the portal) has a personal page where they can publish any other information: photos, documents etc. You can open a user's personal page and comment on their blog posts; send private messages etc. 
  <br />
 </p>
 
<p><a href="/extranet/about/index.php">Official Information</a> - shows the company news headlines for you to be informed of the current events.
<br />

<p><a href="/extranet/docs/">Document library</a> - a public collection of company documents.</p>
 
<p>Have a nice day! 
  <br />
 </p>
 <?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>