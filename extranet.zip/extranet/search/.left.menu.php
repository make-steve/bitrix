<?
$aMenuLinks = Array(
	Array(
		"Site Search", 
		"/extranet/search/index.php", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Site Map", 
		"/extranet/search/map.php", 
		Array(), 
		Array(), 
		"" 
	)
);
?>