<?
$sSectionName = "Search";
$arDirProperties = Array(

);
?>