<?
$aMenuLinks = Array(
	Array(
		"Contact search", 
		"/extranet/contacts/index.php", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Employees", 
		"/extranet/contacts/employees.php", 
		Array(), 
		Array(), 
		"" 
	)
);
?>