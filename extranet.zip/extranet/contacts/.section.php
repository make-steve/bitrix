<?
$sSectionName = "Contacts";
$arDirProperties = array(

);
?>