<?
require($_SERVER["DOCUMENT_ROOT"]."/extranet/mobile/im/index.php");
?>