<?
include($_SERVER["DOCUMENT_ROOT"]."/extranet/mobile/index.php");
?>